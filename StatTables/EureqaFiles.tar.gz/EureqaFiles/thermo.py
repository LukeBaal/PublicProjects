import csv
with open('thermo_data2.csv', 'rb') as f:
    reader = csv.reader(f)
    ls = list(reader)

data = []
for row in ls:
    temp = []
    for item in row:
        # If empty item, skip it
        if len(item)==0:
            continue

        # If not empty, append to list
        temp.append(item)
    data.append(temp)


db = []
for row in data:
    temp = row
    if len(temp) >= 3:
        del temp[0]
        if temp[0].find("H") == -1:
            three = True
            for item in temp:
                if len(item) == 2:
                    three = False
            if three == True:
                db.append(temp)

file = open("constant_data.csv","w")
file.write("H, G, S\n")

for thing in db:
    print_string = ""
    for index in thing:
        temp = str(index)
        print_string += temp.replace('\xe2\x80\x93','-') + ","
    file.write(print_string[:-1] + "\n")
