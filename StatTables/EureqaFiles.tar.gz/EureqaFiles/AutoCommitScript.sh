#!/bin/bash
# Github Auto commit script
cd ~/Documents/PublicProjects

date = $(date +%F)
echo $date
echo $(date +%F)

